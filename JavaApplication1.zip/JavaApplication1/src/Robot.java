public class Robot {
  private int coordX;
  private int coordY;
  private int altura;
  private int ancho;

  public Robot(int coordX, int coordY, int altura, int ancho) {
    this.coordX = coordX;
    this.coordY = coordY;
    this.altura = altura;
    this.ancho = ancho;
  }

  public int getCoordX() {
    return coordX;
  }

  public void setCoordX(int coordX) {
    this.coordX = coordX;
  }

  public int getCoordY() {
    return coordY;
  }

  public void setCoordY(int coordY) {
    this.coordY = coordY;
  }

  public int getAltura() {
    return altura;
  }

  public void setAltura(int altura) {
    this.altura = altura;
  }

  public int getAncho() {
    return ancho;
  }

  public void setAncho(int ancho) {
    this.ancho = ancho;
  }

  public void mover(int nuevaCoordX, int nuevaCoordY) {
    this.coordX = nuevaCoordX;
    this.coordY = nuevaCoordY;
  }

  public int calcularAreaTotal() {
    return altura * ancho;
  }

  public void cambiarColor(String nuevoColor) {
    // cambiar el color del robot
  }
}
