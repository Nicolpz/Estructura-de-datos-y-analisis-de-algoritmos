public class Circulo {
  private int coordX;
  private int coordY;
  private int radio;
  private String color;

  public Circulo(int coordX, int coordY, int radio, String color) {
    this.coordX = coordX;
    this.coordY = coordY;
    this.radio = radio;
    this.color = color;
  }

  public int getCoordX() {
    return coordX;
  }

  public void setCoordX(int coordX) {
    this.coordX = coordX;
  }

  public int getCoordY() {
    return coordY;
  }

  public void setCoordY(int coordY) {
    this.coordY = coordY;
  }

  public int getRadio() {
    return radio;
  }

  public void setRadio(int radio) {
    this.radio = radio;
  }

  public String getColor() {
    return color;
  }

  public void setColor(String color) {
    this.color = color;
  }

  public double calcularArea() {
    return Math.PI * radio * radio;
  }

  public double calcularCircunferencia() {
    return 2 * Math.PI * radio;
  }

  public void cambiarTamaño(int nuevoRadio) {
    this.radio = nuevoRadio;
  }
}
