public class Main {
  public static void main(String[] args) {
    Robot miRobot = new Robot(10, 20, 100, 80);
    System.out.println("Coordenada X del robot: " + miRobot.getCoordX());

    Rectangulo miRectangulo = new Rectangulo(30, 40, 50, 70);
    System.out.println("Altura del rectángulo: " + miRectangulo.getAltura());

    Circulo miCirculo = new Circulo(100, 150, 25, "rojos");
    System.out.println("Color del círculo: " + miCirculo.getColor());
  }
}